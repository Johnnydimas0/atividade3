const express=require('express')
const exphbs=require('express-handlebars')
const app=express()
const hbs=exphbs.create({})
app.engine('handlebars', hbs.engine)
app.set('view engine', 'handlebars')
app.use(express.static('public'))


app.get('/', (req,res)=>{
    const auth=true
    res.render('home',{auth})
    })


app.get('/dashboard', (req,res)=>{
    res.render('dashboard')
})    

app.get('/produtos', (req,res)=>{
    res.render('produtos')
})  

app.get('/contato', (req,res)=>{
    res.render('contato')
}) 

app.get('/sobreNos', (req,res)=>{
    res.render('sobreNos')
}) 




app.listen(8081, ()=>{
    console.log('Servidor ok')
})
